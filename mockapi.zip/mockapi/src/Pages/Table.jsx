import React, { useEffect, useState } from 'react';

const Table = () => {
  const [Data, setData] = useState([]);

  useEffect(() => {
    const getDataFunc = async () => {
      const fetchdata = await fetch("https://66508778ec9b4a4a60326b3e.mockapi.io/shopify/UserRegistration");
      const allData = await fetchdata.json();
      setData(allData);
    };

    getDataFunc();
  }, 0);

  return (
    <div className='container p-2'>
      <table className="table table-dark table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Image</th>
            <th scope="col">User Name</th>
            <th scope="col">User Email</th>
            <th scope="col">Password</th>
            <th scope="col">Created At</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {Data.map((mydata) => (
            <tr key={mydata.id}>
              <th scope="row">{mydata.id}</th>
              <td><img src={mydata.avatar} alt="avatar" /></td>
              <td>{mydata.name}</td>
              <td>{mydata.email}</td>
              <td>{mydata.password}</td>
              <td>{mydata.createdAt}</td>
              <td>
                <button className='btn btn-danger'>Delete</button>
                <button className='btn btn-success'>Edit</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
